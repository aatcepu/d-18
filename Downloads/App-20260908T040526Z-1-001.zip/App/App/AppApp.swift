//
//  AppApp.swift
//  App
//
//  Created by Student on 07/08/26.
//

import SwiftUI

struct AppApp: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    AppApp()
}
