import SwiftUI
import iPhoneNumberField

struct SignIN: View {
    @State private var text: String = ""
    @FocusState private var isFocused: Bool

    var body: some View {
        VStack(spacing: 0) {
            Image("Mask Group")
                .resizable()
                .scaledToFit()
                .ignoresSafeArea()
                .padding(.bottom, 10)

            VStack {
                HStack {
                    Text("Get your groceries\nwith nectar")
                        .foregroundStyle(Color(#colorLiteral(red: 0.01176470588, green: 0.01176470588, blue: 0.01176470588, alpha: 1)))
                        .font(.custom("Gilroy-Light", size: 26))
                        .fontWeight(.medium)
                    Spacer()
                }

                HStack {
                    Text("Mobile Number")
                        .padding(.top, 1)
                    Spacer()
                }

                HStack(spacing: 8) {
                    iPhoneNumberField("", text: $text)
                        .font(UIFont(size: 20, weight: .bold))
                        .flagHidden(false)
                        .flagSelectable(true)
                        .padding(.bottom, 2)
                        .keyboardType(.phonePad)
                        .focused($isFocused)
//                        .overlay(alignment: .leading) {
                            HStack(spacing: 1) {
                                // Adjust this width so the chevron sits just right of the flag
                                Color.clear.frame(width: 24)

                                Image(systemName: "chevron.down")
                                    .offset(x: -4)
                                    .opacity(0.8)
                                    .font(.system(size: 12, weight: .semibold))
                                    .foregroundStyle(.blue)
                            }
                            .allowsHitTesting(false) // let the flag remain tappable
//                        }
                }

                Divider()
                    .background(isFocused ? Color.blue : Color.gray)
            }
            .padding(.horizontal, 20)

            Spacer()
        }
    }
}

#Preview {
    SignIN()
}
