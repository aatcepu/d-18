//
//  FirstTimeDebuggingApp.swift
//  FirstTimeDebugging
//
//  Created by Student on 26/08/26.
//

import SwiftUI

@main
struct FirstTimeDebuggingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
