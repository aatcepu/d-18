//
//  _6augustApp.swift
//  26august
//
//  Created by Student on 26/08/26.
//

import SwiftUI

@main
struct _6augustApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
