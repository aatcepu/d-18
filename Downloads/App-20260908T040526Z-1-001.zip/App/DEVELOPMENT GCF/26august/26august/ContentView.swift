//
//  ContentView.swift
//  26august
//
//  Created by Student on 26/08/26.
//

import SwiftUI

class ViewController: UIViewController{
    override func viewDidLoad() {
        super.viewDidLoad()
        var names = ["Tanmay", "Cole"]
        names.removeFirst()
        names.removeFirst()
        names.removeFirst()
        
        
        
    }
}
