//
//  login_uiApp.swift
//  login ui
//
//  Created by Student on 22/08/26.
//

import SwiftUI

@main
struct login_uiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
